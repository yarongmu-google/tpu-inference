# TP MoE retuning

FP8 weights; FP8 GMM1 rows = 2 * BF16 rows. Times include dispatch and collectives.
Winners are provisional wall-latency results, not device-only timings or serving throughput.

| Tokens | Token tile | FP8/BF16 rows | Status | Median us | Log |
| ---: | ---: | ---: | --- | ---: | --- |
| 512 | 256 | 32/16 | failed | - | t512-tile256-r16/worker.log |
| 512 | 256 | 64/32 | failed | - | t512-tile256-r32/worker.log |
| 512 | 512 | 32/16 | failed | - | t512-tile512-r16/worker.log |
| 512 | 512 | 64/32 | failed | - | t512-tile512-r32/worker.log |
| 1024 | 256 | 32/16 | failed | - | t1024-tile256-r16/worker.log |
| 1024 | 256 | 64/32 | failed | - | t1024-tile256-r32/worker.log |
| 1024 | 512 | 32/16 | failed | - | t1024-tile512-r16/worker.log |
| 1024 | 512 | 64/32 | failed | - | t1024-tile512-r32/worker.log |
| 1024 | 1024 | 32/16 | failed | - | t1024-tile1024-r16/worker.log |
| 1024 | 1024 | 64/32 | failed | - | t1024-tile1024-r32/worker.log |
| 2048 | 256 | 32/16 | failed | - | t2048-tile256-r16/worker.log |
| 2048 | 256 | 64/32 | failed | - | t2048-tile256-r32/worker.log |
| 2048 | 512 | 32/16 | failed | - | t2048-tile512-r16/worker.log |
| 2048 | 512 | 64/32 | failed | - | t2048-tile512-r32/worker.log |
| 2048 | 1024 | 32/16 | failed | - | t2048-tile1024-r16/worker.log |
| 2048 | 1024 | 64/32 | failed | - | t2048-tile1024-r32/worker.log |
| 8192 | 256 | 32/16 | failed | - | t8192-tile256-r16/worker.log |
| 8192 | 256 | 64/32 | failed | - | t8192-tile256-r32/worker.log |
| 8192 | 512 | 32/16 | failed | - | t8192-tile512-r16/worker.log |
| 8192 | 512 | 64/32 | failed | - | t8192-tile512-r32/worker.log |
| 8192 | 1024 | 32/16 | failed | - | t8192-tile1024-r16/worker.log |
| 8192 | 1024 | 64/32 | failed | - | t8192-tile1024-r32/worker.log |
