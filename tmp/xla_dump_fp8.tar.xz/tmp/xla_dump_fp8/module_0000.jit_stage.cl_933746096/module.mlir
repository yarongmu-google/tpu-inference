#loc1 = loc("args[0]")
module @jit_stage attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  func.func public @main(%arg0: tensor<512x4096x256xbf16> loc("args[0]")) -> (tensor<512x4096x256xbf16> {jax.result_info = "result"}) {
    return %arg0 : tensor<512x4096x256xbf16> loc(#loc7)
  } loc(#loc)
} loc(#loc)
#loc = loc(unknown)
#loc2 = loc("/home/ymu_google_com/tpu-inference/tmp/probe_wbw.py":214:23 to :40)
#loc3 = loc("/home/ymu_google_com/tpu-inference/tmp/probe_wbw.py":249:4 to :10)
#loc4 = loc("main"(#loc2))
#loc5 = loc("<module>"(#loc3))
#loc6 = loc(callsite(#loc4 at #loc5))
#loc7 = loc("jit(stage)"(#loc6))
